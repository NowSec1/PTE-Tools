package models

// JSONVersion is JSON Version
const JSONVersion = 4
