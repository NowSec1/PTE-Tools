package config

// IPS is
type IPS string

const (
	// DeepSecurity is
	DeepSecurity IPS = "deepsecurity"
)
