---
name: Feature Request
labels: enhancement
about: I have a suggestion (and might want to implement myself)!
---

<!--
If this is a FEATURE REQUEST, request format does not matter!
-->
