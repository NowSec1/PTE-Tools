adb push libs/radar.dex /data/local/tmp/
