package com.mitchellbosecke.pebble.template;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Locale;
import java.util.Map;

public class PebbleTemplate {

    void evaluate(StringWriter stringWriter) throws IOException {

    }

    void evaluate(Writer writer, Locale locale) throws IOException {

    }

    public void evaluate(Writer writer, Map<String, Object> context) throws IOException {

    }

    public void evaluate(Writer writer, Map<String, Object> context, Locale locale) throws IOException {

    }

}
