package com.mitchellbosecke.pebble;

import com.mitchellbosecke.pebble.template.PebbleTemplate;

public class PebbleEngine {
    public PebbleTemplate getLiteralTemplate(String inputFile) {
        return null;
    }

    public static class Builder {
        public PebbleEngine build() {
            return null;
        }
    }
}
