package com.typesafe.config;

public interface Config {
}
