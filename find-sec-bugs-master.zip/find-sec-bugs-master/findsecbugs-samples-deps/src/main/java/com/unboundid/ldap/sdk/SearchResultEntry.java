package com.unboundid.ldap.sdk;

public class SearchResultEntry extends ReadOnlyEntry {
}
