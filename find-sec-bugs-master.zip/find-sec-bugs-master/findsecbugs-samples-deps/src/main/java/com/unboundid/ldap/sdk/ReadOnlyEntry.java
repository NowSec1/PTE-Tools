package com.unboundid.ldap.sdk;

public class ReadOnlyEntry extends Entry {
}
