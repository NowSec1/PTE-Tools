package com.unboundid.ldap.sdk;

public class Entry {
    public final String getDN() {
        return null;
    }
}
