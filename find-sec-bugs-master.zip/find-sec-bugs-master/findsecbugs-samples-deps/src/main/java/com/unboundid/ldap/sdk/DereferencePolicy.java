package com.unboundid.ldap.sdk;

import java.io.Serializable;

public class DereferencePolicy implements Serializable {

}
