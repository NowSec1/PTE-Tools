package com.unboundid.ldap.sdk;

public class LDAPException extends Exception {
    public ResultCode getResultCode() {
        return null;
    }
}
