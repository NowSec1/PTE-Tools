package com.google.common.escape;

public abstract class Escaper {
    public abstract String escape(String string);
}
