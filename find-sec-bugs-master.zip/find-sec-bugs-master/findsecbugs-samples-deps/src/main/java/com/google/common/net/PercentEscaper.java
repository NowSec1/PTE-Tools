package com.google.common.net;

import com.google.common.escape.Escaper;

public class PercentEscaper extends Escaper {
    @Override
    public String escape(String string) {
        return null;
    }
}
