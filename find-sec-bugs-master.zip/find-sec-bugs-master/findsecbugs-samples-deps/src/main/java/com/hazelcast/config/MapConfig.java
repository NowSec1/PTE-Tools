package com.hazelcast.config;

public class MapConfig {
    public void setName(String name) {
    }

    public void setTimeToLiveSeconds(int timeToLiveSeconds) {
    }
}
