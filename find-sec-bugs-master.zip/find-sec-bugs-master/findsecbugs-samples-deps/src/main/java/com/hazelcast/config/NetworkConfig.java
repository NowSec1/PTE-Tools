package com.hazelcast.config;

public class NetworkConfig {
    public void setSymmetricEncryptionConfig(SymmetricEncryptionConfig symmetricEncryptionConfig) {

    }
}
