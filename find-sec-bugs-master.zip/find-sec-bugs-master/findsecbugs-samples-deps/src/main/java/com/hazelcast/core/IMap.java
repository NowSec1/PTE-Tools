package com.hazelcast.core;

import java.util.Map;

public interface IMap<K, V> extends Map<K, V> {
}
