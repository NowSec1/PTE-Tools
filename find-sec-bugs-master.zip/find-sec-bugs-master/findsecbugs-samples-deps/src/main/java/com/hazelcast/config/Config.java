package com.hazelcast.config;

public class Config {
    public void addMapConfig(MapConfig myMapConfig) {

    }

    public void setNetworkConfig(NetworkConfig networkConfig) {

    }
}
