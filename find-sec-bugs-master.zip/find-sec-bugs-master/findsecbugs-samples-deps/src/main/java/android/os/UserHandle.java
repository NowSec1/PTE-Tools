package android.os;

public final class UserHandle {
}
