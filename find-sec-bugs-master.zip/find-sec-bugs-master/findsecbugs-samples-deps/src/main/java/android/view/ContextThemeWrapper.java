package android.view;

import android.content.ContextWrapper;

public class ContextThemeWrapper extends ContextWrapper {
}
