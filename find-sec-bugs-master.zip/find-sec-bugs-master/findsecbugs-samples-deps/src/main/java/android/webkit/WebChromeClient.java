package android.webkit;

public class WebChromeClient {
    public void onGeolocationPermissionsShowPrompt (String origin, GeolocationPermissions.Callback callback) {

    }
}
