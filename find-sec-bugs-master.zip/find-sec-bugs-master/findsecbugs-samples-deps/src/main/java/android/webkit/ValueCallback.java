package android.webkit;

public interface ValueCallback<T> {
    void onReceiveValue (T value);
}
