package android.content;

import android.net.Uri;

public class UriMatcher
{
    public static final int NO_MATCH = -1;

    public UriMatcher(int code)
    {
        throw new RuntimeException("Stub!");
    }

    public void addURI(String authority, String path, int code)
    {
        throw new RuntimeException("Stub!");
    }

    public int match(Uri uri)
    {
        throw new RuntimeException("Stub!");
    }
}
