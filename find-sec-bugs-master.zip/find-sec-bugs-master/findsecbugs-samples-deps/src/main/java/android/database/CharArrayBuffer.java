package android.database;

public final class CharArrayBuffer
{
    public CharArrayBuffer(int size)
    {
        throw new RuntimeException("Stub!");
    }

    public CharArrayBuffer(char[] buf)
    {
        throw new RuntimeException("Stub!");
    }

    public char[] data = null;
    public int sizeCopied;
}