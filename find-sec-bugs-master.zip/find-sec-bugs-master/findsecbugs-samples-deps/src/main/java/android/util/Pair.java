package android.util;

public class Pair<F, S>
{
    public F first;
    public S second;
}
