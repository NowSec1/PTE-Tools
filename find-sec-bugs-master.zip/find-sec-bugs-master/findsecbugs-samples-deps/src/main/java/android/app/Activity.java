package android.app;

import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;

public class Activity extends ContextThemeWrapper {


    protected void onCreate(Bundle savedInstanceState) {

    }

    public View findViewById(int id) {
        return null;
    }
}
