# Headhunter
Welcome to **Headhunter**, a security scanner for HTTP response headers.

(in progress)
