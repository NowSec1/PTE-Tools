# XSpear on Burpsuite
<img src="https://1.bp.blogspot.com/-P_MFaYn37Ps/XgjBrDN41lI/AAAAAAAAEzQ/WQbrkvwfEBYuqYLrotA2CUflMwQ3hEKpACLcBGAsYHQ/s640/1413.png" width=100%> 

## Blog post
https://www.hahwul.com/2019/12/run-other-application-on-burp-suiteburp.html

## Custom Send to
go to BApp store

## Entries
```
Name: XSpear
Command: xspear --raw %F -a -b {your-blind-xss-url}
```

## Miscellaneous
```
# MacOS 
~~your-path~~/open_terminal_with_args/otwa.sh %C

# Linux
(default) xterm %C
```

<img src="https://1.bp.blogspot.com/-WDmUI8QzX-4/XgjAx3TX3sI/AAAAAAAAEyw/YKKC23hLVYQtkBvPl_T7UybSL5RYKi-UwCLcBGAsYHQ/s640/1415.png" width=100%>
