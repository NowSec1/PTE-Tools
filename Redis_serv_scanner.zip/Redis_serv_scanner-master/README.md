# Redis_serv_scanner
一款python打造的redis扫描器，可实现网段下多线程批量扫描



命令行下传入参数即可：
## 示例：
python Redis_scanner.py 192.168.1.1 192.168.1.255 5

#python 命令行运行的python版本

#Redis_scanner.py 脚本名称

后面为开始ip 和 结束ip

最后一个参数表示线程个数
