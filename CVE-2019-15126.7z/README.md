# kr00k
PoC of CVE-2019-15126 kr00k vulnerability

## Installation
```
apt-get install aircrack-ng
pip install -r requirements.txt
```


## Disclaimer

## Usage 
usage: kr00k.py [-h] [-i INTERFACE] [-t VICTIM] [-v VERBOSE] [-c CHANNEL]
                [-w WRITE_TO] [-r READ] [--bssid BSSID]

optional arguments:
  -i INTERFACE,   --interface INTERFACE
  -t VICTIM,      --target VICTIM
  -v VERBOSE,     --verbose VERBOSE
  -c CHANNEL,     --channel CHANNEL
  -w WRITE_TO,    --write WRITE_TO
  -r READ,        --read READ
  --bssid         BSSID
