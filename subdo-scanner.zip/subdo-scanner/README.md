# subdo-scanner
Simple a subdomain scanner python

How to install?
```
$ pkg install git
$ pkg install python
$ git clone https://github.com/DH4CK1/subdo-scanner
$ cd subdo-scanner
$ pip2 install -r requirements.txt
$ python2 scan.py
```
