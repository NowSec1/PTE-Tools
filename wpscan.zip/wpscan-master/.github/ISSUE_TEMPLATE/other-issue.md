---
name: Other Issue
about: Create a report which is not a related to a Bug or Feature
title: ''
labels: ''
assignees: ''

---

Before submitting an issue, please make sure you fully read any potential error messages output and did some research on your own.
