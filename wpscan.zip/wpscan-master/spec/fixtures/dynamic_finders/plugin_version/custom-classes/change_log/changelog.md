# Change Log

## [1.0.0] - 2017-09-27

### Added

* The add new and edit term (category, tag, etc.) screens now have an input box for changing the body class.

### Changed

* PHP 5.3.0+ is now required.
* Overhauled the entire plugin from the ground up.

## [0.1.0]

* Plugin launch.  Everything's new!
