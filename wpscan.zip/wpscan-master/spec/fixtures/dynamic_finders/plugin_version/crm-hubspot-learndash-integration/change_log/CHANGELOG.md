# Changelog

## 1.0.1

- Typo in plugin name

## 1.0.0

- Initial
