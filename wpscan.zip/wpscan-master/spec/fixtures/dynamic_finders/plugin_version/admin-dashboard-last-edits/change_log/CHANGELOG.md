# Admin Dashboard Last Edits
## Changelog
### 1.1.3
* Minor readme corrections

### 1.1.2
* Minor readme enhancements

### 1.1.1
* Deleted german translation for opening the plugin to the GlotPress community

### 1.1
* Added edit icon in front of the page or post title
* Added date of the editing
* Minor fixes in the readme
* Updated german translation
* Added new screenshots

### 1.0
* Initial version
* German translation
