#-------------------------
# ScanT3r Config File .. |
#-------------------------
# HTTPS Cert
vert = True
# Allow Redirects
redir=False
