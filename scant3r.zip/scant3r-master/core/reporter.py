#!/usr/bin/env python

def make_report(vuln):
	pass
