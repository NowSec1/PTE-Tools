def phoneapis():
    api= "2f8c8e865a0b25bbf4da08c4db039b8d"
    return str(api)
def ipstack():
    api="276cfee2c31729505691e515e8321a02"
    return str(api)
def gmap():
    api="AIzaSyAKGik6Fok3_mbIsgquaAnDGNy-h_AjhVw"
    return str(api)
